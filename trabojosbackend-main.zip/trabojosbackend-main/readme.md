git push -u newOrigin main to push to repo
