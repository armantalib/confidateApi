const express = require('express');
const router = express.Router();
const multer = require('multer');
const mime = require('mime-types');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "routes/uploads");
  },
  filename: (req, file, cb) => {
    // Generate a unique filename using a timestamp
    const timestamp = Date.now();
    const extension = mime.extension(file.mimetype);
    const filename = `${timestamp}.${extension}`;
    cb(null, filename);
  },
});

const upload = multer({ storage: storage });

router.post('/upload', upload.single("image"), async (req, res) => {
  res.send({ message: 'image is saved', image: "image/" + req.file.filename })
});


router.get('/:key', async (req, res) => {
  try {
    const key = req.params.key;
    res.sendFile(path.join(__dirname, "./uploads/" + key));
  } catch (error) {
    res.status(500).send('Error fetching image: ' + error.message);
  }
});

module.exports = router; 
